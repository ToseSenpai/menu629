# Menu Sorting 📃
![alt text](public/thumbnail.jpg)
## Technologies used:
- `React.js`
- `Emotion.sh`
- `Framer-Motion`
