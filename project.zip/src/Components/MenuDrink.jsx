import { motion } from "framer-motion";
import imgDrinkIcon from "../img/undraw_breakfast.svg";
import "./MenuDrink.css"; // Importa il CSS specifico

const MenuDrink = ({ drink, items }) => {
  const categories = ["cocktail", "mocktail", "wine", "beer", "coffee", "juice"];

  const itemContainer = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.3 },
    },
    exit: { opacity: 0 },
  };

  return (
    <div className="menu-drink-container">
      {categories.map((category) => (
        <div key={category} className="drink-category">
          <h3 className="category-title">{category}</h3>
          <div className="category-items">
            {drink &&
              items
                .filter((item) => item.category === category)
                .map((item, i) => (
                  <motion.div
                    className="menu-item"
                    key={item.id}
                    variants={itemContainer}
                    initial="hidden"
                    animate="visible"
                    exit="exit"
                  >
                    <img src={imgDrinkIcon} alt={`${category} icon`} className="category-icon" />
                    <motion.div className="item-content">
                      <motion.div className="item-title-box">
                        <motion.h5 className="item-title">{item.title}</motion.h5>
                        <motion.h5 className="item-price">${item.price}</motion.h5>
                      </motion.div>
                      <motion.p className="item-desc">{item.desc}</motion.p>
                      {/* Bottoni visibili solo in MenuDrink */}
                      <button className="drink-button">Order Now</button>
                    </motion.div>
                  </motion.div>
                ))}
          </div>
        </div>
      ))}
    </div>
  );
};

export default MenuDrink;
